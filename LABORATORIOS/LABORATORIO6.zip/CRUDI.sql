/*CRUDI--- PC_OPINION*/
CREATE OR REPLACE PACKAGE BODY PC_OPINION IS 

	PROCEDURE adicionar_opinion (
		xnumero         IN  NUMBER,
		xfecha          IN  DATE,
		xopinion        IN  VARCHAR,
		xjustificacion  IN  VARCHAR,
		xcodigo         IN  NUMBER,
		xcodigo_bien    IN  VARCHAR
	) IS 
	BEGIN
	INSERT INTO opinion (
		numero,
		fecha,
		opinion,
		justificacion,
		codigo,
		codigo_bien
	) VALUES (
		xnumero,
		xfecha,
		xopinion,
		xjustificacion,
		xcodigo,
		xcodigo_bien
	);

	COMMIT;
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			raise_application_error(-200010, 'No se puede insertar esta opinion');
	END;
		
	
	
	PROCEDURE modificar_opinion (
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR,
		xnumero         IN  NUMBER
    ) IS 
	BEGIN
	UPDATE opinion SET opinion = xopinion, justificacion = xjustificacion WHERE xnumero = numero;
	COMMIT;
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			raise_application_error(-200011, 'No se puede modificar esta opinion');
	END;	
	

	
	PROCEDURE eliminar_opinion (
        xnumero IN NUMBER
    ) IS 
    BEGIN 
	DELETE FROM opinion WHERE xnumero = numero;
	COMMIT;
	EXCEPTION
		WHEN OTHERS THEN
			ROLLBACK;
			raise_application_error(200012, 'No se puede eliminar esta opinion');
	END;
	
	
	
	PROCEDURE adicionar_grupal (
        xrazon          IN  XMLTYPE,
        xestrellas      IN  NUMBER,
        xnumero         IN  NUMBER,
        xfecha          IN  DATE,
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR,
        xcodigo         IN  NUMBER,
        xcodigo_bien    IN  VARCHAR
    )IS 
	BEGIN 
	INSERT INTO opinion_grupal(razon,estrellas,numero,fecha,opinion,justificacion,codigo,codigo_bien) VALUES(xrazon,xestrellas,xnumero,xfecha,xopinion,xjustificacion,xcodigo,xcodigo_bien);
	COMMIT;
	EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
			RAISE_APPLICATION_ERROR(200013, 'No se puede insertar esta opinion grupal');
	END;
	
	
	
	PROCEDURE modificar_grupal (
        xrazon          IN  XMLTYPE,
        xestrellas      IN  NUMBER,
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR,
		xnumero 		IN  NUMBER
    )IS
	BEGIN 
	UPDATE opinion_grupal SET razon = xrazon,estrellas = xestrellas,opinion = xopinion,justificacion = xjustificacion WHERE xnumero = numero;
	COMMIT;
	EXCEPTION 
	WHEN OTHERS THEN
		ROLLBACK;
			RAISE_APPLICATION_ERROR(200014, 'No se puede modificar esta opinion grupal');
	END;
	
	
	
	PROCEDURE eliminar_grupal (
        xnumero IN NUMBER
    )IS
	BEGIN 
	DELETE FROM opinion_grupal WHERE xnumero = numero;
	COMMIT;
	EXCEPTION 
	WHEN OTHERS THEN 
		ROLLBACK;
			RAISE_APPLICATION_ERROR(200015, 'No se puede eliminar esta opinion grupal');
	END;
	
	END PC_OPINION;




/*--CRUDI PC_BIENES*/
CREATE OR REPLACE PACKAGE BODY PC_BIENES IS

	PROCEDURE ADICIONAR_BIEN (xcodigo IN  VARCHAR, xnombre IN VARCHAR , xtipo  IN VARCHAR, xmedida  IN VARCHAR, xunitario  IN NUMBER , xretirado IN NUMBER) IS
	BEGIN
		INSERT INTO BIEN (codigo,nombre,tipo,medida,unitario,retirado) VALUES (xcodigo,xnombre,xtipo,xmedida,xunitario,xretirado);
		COMMIT;
		EXCEPTION WHEN OTHERS THEN
		ROLLBACK;
        RAISE_APPLICATION_ERROR(-10050, 'No se puede insertar el bien.');
	END;
	
	PROCEDURE MODIFICAR_BIEN (xunitario IN  NUMBER, xretirado IN NUMBER , xcodigo IN VARCHAR) IS
	BEGIN
		UPDATE Bien SET unitario  =  xunitario , retirado = xretirado WHERE   xcodigo = codigo;
		COMMIT;
		EXCEPTION WHEN OTHERS THEN
		ROLLBACK;
        RAISE_APPLICATION_ERROR(-10051, 'No se puede modificar el bien.');
	END;
	
	PROCEDURE ELIMINAR_BIEN (xcodigo IN  VARCHAR) IS
	BEGIN
		DELETE FROM Bien WHERE codigo = xcodigo;
		COMMIT;
		EXCEPTION WHEN OTHERS THEN
		ROLLBACK;
        RAISE_APPLICATION_ERROR(-10052, 'No se puede eliminar el bien.');
	END;
	
	PROCEDURE ELIMINAR_REEMPLAZO (xbien IN  NUMBER)IS
	BEGIN
		DELETE FROM Reemplazo WHERE bien = xbien;
		COMMIT;
		EXCEPTION WHEN OTHERS THEN
		ROLLBACK;
        RAISE_APPLICATION_ERROR(-10052, 'No se puede eliminar el reemplazo.');
	END;
	
	PROCEDURE MODIFICAR_REEMPLAZO (xbien IN  NUMBER, xreemplazo IN NUMBER) IS
	BEGIN
		UPDATE Bien SET reemplazo  =  xreemplazo WHERE bien = xbien;
		COMMIT;
		EXCEPTION WHEN OTHERS THEN
		ROLLBACK;
        RAISE_APPLICATION_ERROR(-10051, 'No se puede modificar el reemplazo.');
	END;
	
	
	
PROCEDURE ADICIONAR_REEMPLAZO (xbien IN  NUMBER,xreemplazo IN NUMBER)IS
	BEGIN
		INSERT INTO Reemplazo (bien,reemplazo) VALUES (xbien,xreemplazo);
		COMMIT;
		EXCEPTION WHEN OTHERS THEN
		ROLLBACK;
        RAISE_APPLICATION_ERROR(-10050, 'No se puede insertar el reemplazo.');
	END;



	FUNCTION BIENES_RECLAMOS RETURN SYS_REFCURSOR IS X SYS_REFCURSOR;
    BEGIN
        OPEN X FOR 
        (SELECT codigo, nombre , EXTRACTVALUE(Opiniongrupal.razon,'count(/TRazon)') AS Razones INTO A,EXTRACTVALUE(Opiniongrupal.razon,'count(/TRazon/Reclamos)') AS RazonesConReclamo INTO B, (B*100)/A AS PorcentajeDeReclamos
         JOIN Opinion ON Opinion.codigo_bien = Bien.codigo
         JOIN Opoiniongrupal ON Opiniongrupal.numero = Opinion.numero
         WHERE PorcentajeDeReclamos > 49);
    END;



FUNCTION BIENES_POPULARES RETURN SYS_REFCURSOR IS X SYS_REFCURSOR;
    BEGIN
        OPEN X FOR 
        (SELECT Bien.nombre,Bien.tipo,MAX(Generico.cantidad) INTO MG,MAX(Perecederos.cantidad) INTO MP,MAX(Vestuario.cantidad) INTO MV
         JOIN Detalle ON Bien.codigo = Detalle.codigo
         JOIN Vestuario ON Detalle.orden = Vestuario.orden
         JOIN Perecederos ON Perecederos.oreden = Detalle.orden
         JOIN Generico ON Detalle.orden = Generico.orden
         WHERE Vestuario.cantidad = MV OR Perecederos.cantidad = MP OR Generico.cantidad = MG)
    END;
	
	
END PC_BIENES;