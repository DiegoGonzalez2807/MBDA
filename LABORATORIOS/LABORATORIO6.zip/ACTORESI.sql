/*ACTORESI --- PA_BENEFICIARIO*/
CREATE OR REPLACE PACKAGE BODY PA_BENEFICIARIO IS
	FUNCTION ADD_Opinion_Beneficiario RETURN SYS_REFCURSOR IS Insertar_opina_BEN SYS_REFCURSOR;
	BEGIN
		Insertar_opina_BEN := PC_OPINION.adicionar_opinion;
		RETURN Insertar_opina_BEN;
	END;
	
	
	
	FUNCTION MOD_Opinion_Beneficiario RETURN SYS_REFCURSOR IS Modificar_opina_BEN SYS_REFCURSOR;
	BEGIN	
		Modificar_opina_BEN := PC_OPINION.modificar_opinion;
		RETURN Modificar_opina_BEN;
	END;
	
	
	
	FUNCTION DEL_Opinion_Beneficiario RETURN SYS_REFCURSOR IS Elimina_Opina_BEN SYS_REFCURSOR;
	BEGIN
		Elimina_Opina_BEN := PC_OPINION.eliminar_opinion;
		RETURN Elimina_Opina_BEN;
	END;
	
	

	FUNCTION ADD_Grupal_Beneficiario RETURN SYS_REFCURSOR IS Insertar_grupal_BEN SYS_REFCURSOR;
	BEGIN
		Insertar_grupal_BEN := PC_OPINION.adicionar_grupal;
		RETURN Insertar_grupal_BEN;
	END;
	
	
	
	FUNCTION MOD_Grupal_Beneficiaro RETURN SYS_REFCURSOR IS Modifica_grupal_BEN SYS_REFCURSOR;
	BEGIN
		Modifica_grupal_BEN := PC_OPINION.modificar_grupal;
		RETURN Modifica_grupal_BEN;
	END;
	
	
	
	FUNCTION Bienes_Populares_Mes RETURN SYS_REFCURSOR IS Consulta_populares SYS_REFCURSOR;
	BEGIN
		Consulta_populares := PC_BIENES.BIENES_POPULARES;
		RETURN Consulta_populares;
	END;
	
	END PA_BENEFICIARIO;
		
		
		
		
/*ACTORESI --- PA_AUDITOR*/
CREATE OR REPLACE PACKAGE BODY PA_AUDITOR IS 

	FUNCTION Bienes_Populares_Mes RETURN SYS_REFCURSOR IS Consulta_bien_popular SYS_REFCURSOR;
	BEGIN
		Consulta_bien_popular := PC_BIENES.BIENES_POPULARES;
		RETURN Consulta_bien_popular;
	END;
	
	
	
	FUNCTION Bienes_con_reclamos RETURN SYS_REFCURSOR IS Consulta_bien_reclamo SYS_REFCURSOR;
	BEGIN
		Consulta_bien_reclamo := PC_BIENES.BIENES_RECLAMOS;
		RETURN Consulta_bien_reclamo;
	END;
	
	
	
	FUNCTION Localidad_de_asignacion RETURN SYS_REFCURSOR IS Consulta_localidad SYS_REFCURSOR;
	BEGIN
		OPEN Consulta_localidad_asigna FOR
			SELECT familia.nombre 
			FROM familia,asignacion,bien
			WHERE familia.numero = asignacion.numerofamilia AND asignacion.numero = bien.numero AND asignacion.aceptado = 1;
		RETURN Consulta_localidad;
	END;
	
	
	
	FUNCTION Detalle_asignacion RETURN SYS_REFCURSOR IS Consulta_detalle_asigna SYS_REFCURSOR;
	BEGIN 
		OPEN Consulta_detalle_asigna FOR 
			SELECT opinion.codigo_bien, bien.nombre, asignacion.numero, familia.numero, opinion.numero, opinion.justificacion
			FROM opinion,bien,asignacion,familia
			WHERE opinion.codigo_bien = bien.codigo AND bien.numero = asignacion.numero AND asignacion.numerofamilia = familia.numero AND familia.codigo_representante = opinion.codigo;
		RETURN Consulta_detalle_asigna;
	END;
	
	
	
	FUNCTION Modificar_Bienes RETURN SYS_REFCURSOR IS Modificacion_Bienes SYS_REFCURSOR;
	BEGIN
		Modificacion_Bienes := PC_BIENES.MODIFICAR_BIEN;
		RETURN Modificacion_Bienes;
	END;



END PA_AUDITOR;