/*CRUDE -- PC_OPINION*/
CREATE OR REPLACE PACKAGE pc_opinion IS
    PROCEDURE adicionar_opinion (
        xnumero         IN  NUMBER,
        xfecha          IN  DATE,
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR,
        xcodigo         IN  NUMBER,
        xcodigo_bien    IN  VARCHAR
    );

    PROCEDURE eliminar_opinion (
        xnumero IN NUMBER
    ); /*Para eliminar todo, solo se tiene que eliminar la llave primaria para que no exista*/
	
	        PROCEDURE modificar_opinion (
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR
    );/*Solo elementos que sean viables o que se puedan modificar*/
	
	        PROCEDURE adicionar_grupal (
        xrazon          IN  XMLTYPE,
        xestrellas      IN  NUMBER,
        xnumero         IN  NUMBER,
        xfecha          IN  DATE,
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR,
        xcodigo         IN  NUMBER,
        xcodigo_bien    IN  VARCHAR
    );

    PROCEDURE modificar_grupal (
        xrazon          IN  XMLTYPE,
        xestrellas      IN  NUMBER,
        xopinion        IN  VARCHAR,
        xjustificacion  IN  VARCHAR
    );

    PROCEDURE eliminar_grupal (
        xnumero IN NUMBER
    );
END pc_opinion;
	
	
	
/*CRUDE -- PC_BIENES*/
CREATE OR REPLACE PACKAGE PC_BIENES IS 
	PROCEDURE ADICIONAR_BIEN (xcodigo IN  VARCHAR,
							  xnombre IN VARCHAR ,
							  xtipo  IN VARCHAR,
							  xmedida  IN VARCHAR,
							  xunitario  IN NUMBER , 
							  xretirado IN NUMBER);
	PROCEDURE MODIFICAR_BIEN (xunitario IN  NUMBER,
							  xretirado IN NUMBER ,
							  xnumero  IN NUMBER);
	PROCEDURE ELIMINAR_BIEN (xcodigo IN  VARCHAR);
	
	FUNCTION BIENES_RECLAMOS RETURN SYS_REFCURSOR;
	FUNCTION BIENES_POPULARES RETURN SYS_REFCURSOR;
	PROCEDURE ADICIONAR_REEMPLAZO (xbien IN  NUMBER,
								   xreemplazo IN NUMBER);
	PROCEDURE MODIFICAR_REEMPLAZO (xbien IN  NUMBER,
								   xreemplazo IN NUMBER);
	PROCEDURE ELIMINAR_REEMPLAZO (xbien IN  NUMBER);
	
END PC_BIENES;