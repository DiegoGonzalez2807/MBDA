/*Seguridad NO OK*/
/Beneficiario/
INSERT INTO BIEN (codigo,nombre,tipo,medida,unitario,retirado) VALUES ('PI2016','Pan','P','XS',3500,0);
UPDATE Bien SET unitario  =  2000 , retirado = 1 WHERE  codigo = 'PI2016';
DELETE FROM Bien WHERE codigo = 'PI2016';
/Auditor/
INSERT INTO opinion (
        numero,
        fecha,
        opinion,
        justificacion,
        codigo,
        codigo_bien
    ) VALUES (
        15956,TO_DATE('1995/09/02','yyyy/mm/dd'), 'B', 'Buen producto', 8525695, 'BI956'
    );
UPDATE opinion SET opinion = 'M' AND justificacion = 'Mal producto' WHERE 15956 = numero;
DELETE FROM opinion WHERE numero = 15956