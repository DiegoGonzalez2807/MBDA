/*LABORATORIO 6 MBDA*/

/*1. Extendiendo BENEFICIARIOS*/

/*Consulte la información que actualmente está en esa tabla*/
SELECT * FROM mbda.BENEFICIARIOS;

/*Inclúyanse como adultos. (Los dos como adultos de una nueva familia)*/
INSERT INTO mbda.BENEFICIARIOS VALUES(20,0,8585625,'Diego Gonzalez','M','2000/07/28',1008562541,'diegog@gmail.com', 3123222568);
INSERT INTO mbda.BENEFICIARIOS VALUES(20,0,6584741,'Cristian Forero','M','2001/09/10',100854162,'cristianf@gmail.com', 9582415);
COMMIT;

/*Traten de modificarse o borrarse. ¿qué pasa?*/
DELETE FROM mbda.BENEFICIARIOS WHERE codigo = 8585625;
DELETE FROM mbda.BENEFICIARIOS WHERE codigo = 6584741;
/*Lo que pasa con eliminar o modificar datos en esta tabla es que no tenemos los permisos necesarios para hacer este tipo de tareas*/



/*Escriban la instrucción necesaria para otorgar los permisos que actualmente tiene la tabla BENEFICIARIOS. ¿quién la escribió?*/
GRANT INSERT ON mbda.BENEFICIARIOS TO PUBLIC;
GRANT SELECT ON mbda.BENEFICIARIOS TO PUBLIC;


/*Escriban las instrucciones necesarias para importar los datos de esa tabla a su base de datos*/
INSERT INTO Personas (codigo, nombre, genero, talla,nacimiento)
    SELECT distinct m.codigo, m.nombre, genero,'M',TO_DATE(nacimiento,'YYYY/MM/DD')
    FROM mbda.BENEFICIARIOS m
    WHERE REGEXP_LIKE (SUBSTR(nacimiento,4,1), '[0-9]')
    AND nacimiento NOT LIKE '%-%'
    AND SUBSTR(nacimiento,1,4) NOT LIKE '%/%'
    AND TO_NUMBER(SUBSTR(nacimiento,6,2)) BETWEEN 0 AND 12
    AND representante = 1
    AND m.CODIGO > ALL(
        SELECT CODIGO
        FROM mbda.BENEFICIARIOS
        WHERE REPRESENTANTE = 1
        AND familia = m.familia
        AND codigo != m.codigo
        )
    AND m.familia NOT IN (SELECT numero FROM Familias)
    ;