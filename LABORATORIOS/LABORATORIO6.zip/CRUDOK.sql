/*CRUD OK*/

/*PC_OPINION*/
/*adicionar_opinion*/
BEGIN
	PC_OPINION.adicionar_opinion(15956,TO_DATE('1995/09/02','yyyy/mm/dd'), 'B', 'Buen producto', 8525695, 'BI956');
END;
/
/*modificar_opinion*/
BEGIN
	PC_OPINION.modificar_opinion('M', 'Mal producto', 15956);
END;
/
/*eliminar opinion*/
BEGIN
	PC_OPINION.eliminar_opinion(15956);
END;
/
/*adicionar opinion grupal*/
BEGIN
PC_OPINION.adicionar_grupal('<TRazon>
		<Comentarios> 
			<Adjetivo>Pésimmo</Adjetivo>
			<Descripcion>Producto en muy mal estado</Descripcion>
			<Puntaje>2</Puntaje>
		</Comentarios>
		
		<Sugerencias Idea_Mejoramiento = "Revisar el estado del producto">
			<Adjetivo>Regular</Adjetivo>
			<Descripcion>Se puede mejorar la calidad</Descripcion>
			<Puntaje>25</Puntaje>
		</Sugerencias>
		
		<Reclamos Daño = "1000000">
			<Adjetivo>Pesimo</Adjetivo>
			<Descripcion>Se daño por completo el producto</Descripcion>
			<Puntaje>0</Puntaje>
		</Reclamos>
	</TRazon>',4,25255,TO_DATE('1995/09/02','yyyy/mm/dd'), 'B', 'Buen estado', 2525698, 'BI956');
END;
/
/*modificar opinion grupal*/
BEGIN
	PC_OPINION.modificar_grupal('<TRazon>
		<Comentarios> 
			<Adjetivo>Regular</Adjetivo>
			<Descripcion>Producto aceptable</Descripcion>
			<Puntaje>3</Puntaje>
		</Comentarios>
		
		<Sugerencias Idea_Mejoramiento = "Revisar el estado del producto">
			<Adjetivo>Regular</Adjetivo>
			<Descripcion>Se puede mejorar la calidad</Descripcion>
			<Puntaje>25</Puntaje>
		</Sugerencias>
		
		<Reclamos Daño = "1000">
			<Adjetivo>Aceptable</Adjetivo>
			<Descripcion>No se dañó por completo</Descripcion>
			<Puntaje>0</Puntaje>
		</Reclamos>
	</TRazon>','Regular estado' ,25255);
END;
/
/*eliminar opinion grupal*/
BEGIN
PC_OPINION.eliminar_grupal(25255);
END;
/




/



/*paquete ok*/
PC_BIENES.ADICIONAR_BIEN('PI2016','Pan','P','XS',3500,0);
PC_BIENES.ADICIONAR_BIEN('PI2016','Pan','P','XS',3500,'True');
PC_BIENES.MODIFICAR_BIEN('2600',1,'PI2016');
PC_BIENES.MODIFICAR_BIEN('2600','TRUE','PI2016');
PC_BIENES.ELIMINAR_BIEN('PI2016');
PC_BIENES.ELIMINAR_BIEN(111);
